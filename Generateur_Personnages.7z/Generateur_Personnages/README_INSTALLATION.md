# Générateur de Personnages

Ce programme est un générateur de personnages.

## Installation

1. Assurez-vous d'avoir Python installé sur votre ordinateur (version 3.6 ou supérieure recommandée)
   - Vous pouvez télécharger Python depuis [python.org](https://www.python.org/downloads/)

2. Installez les dépendances nécessaires en ouvrant une invite de commande et en exécutant :
   ```
   pip install python-docx
   ```

## Lancement du programme

1. Décompressez tous les fichiers du zip dans un dossier
2. Double-cliquez sur le fichier `generateur_PJ.py` pour lancer le programme
   - Ou ouvrez une invite de commande, naviguez jusqu'au dossier et exécutez `python generateur_PJ.py`

## Utilisation

1. L'interface vous permet de créer un personnage en sélectionnant :
   - Une classe (Corsaire, Lurquin, Occultiste, etc.)
   - Des attributs (Agilité, Âme, Force, etc.)
   - Des compétences
   - Des talents
   - Des équipements

2. Vous pouvez sauvegarder votre personnage :
   - Au format DOCX pour l'impression en utilisant le bouton "Générer Fiche"
   - Au format JSON pour charger ultérieurement le personnage en utilisant le bouton "Sauvegarder"

3. Vous pouvez charger un personnage précédemment sauvegardé en utilisant le bouton "Charger" et en sélectionnant le fichier JSON correspondant.

## Contenu du package

- `generateur_PJ.py` : Le programme principal
- `classes.json` : Définitions des classes de personnages
- `competences.json` : Liste des compétences disponibles
- `talents.json` : Liste des talents disponibles
- `catalogue_equipement.json` : Catalogue des équipements disponibles
- `pirate_skull.png` : Image utilisée dans l'interface
- `requirements.txt` : Liste des dépendances Python

## Résolution de problèmes

- Si vous rencontrez une erreur liée aux chemins de fichiers, assurez-vous que tous les fichiers JSON sont bien dans le même dossier que le programme principal.
- Si vous avez des problèmes avec la bibliothèque python-docx, essayez de la réinstaller avec `pip install --upgrade python-docx`
