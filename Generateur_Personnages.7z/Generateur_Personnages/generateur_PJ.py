import tkinter as tk
from tkinter import ttk, messagebox, filedialog, font, PhotoImage
from docx import Document
from docx.oxml.shared import OxmlElement
from docx.oxml.ns import qn
import re
import json
from functools import lru_cache
import os
import pathlib
import json
import re
from functools import lru_cache, partial

class CreateToolTip(object):
    def __init__(self, widget, text):
        self.widget = widget
        self.text = text
        self.tipwindow = None
        widget.bind("<Enter>", self.enter)
        widget.bind("<Leave>", self.leave)

    def enter(self, event=None):
        if self.tipwindow:
            return
        x = self.widget.winfo_rootx() + 25
        y = self.widget.winfo_rooty() + 20
        self.tipwindow = tw = tk.Toplevel(self.widget)
        tw.wm_overrideredirect(True)
        tw.wm_geometry(f"+{x}+{y}")
        frame = tk.Frame(tw, background="#fffbe6")
        frame.pack(fill='both', expand=True)
        label = tk.Label(
            frame,
            text=self.text,
            justify='left',
            background="#fffbe6",
            relief='solid',
            borderwidth=1,
            wraplength=220,
            font=("Georgia", 10, "italic"),
            fg="#6b3e26"
        )
        label.pack(ipadx=1, padx=4, pady=4)

    def leave(self, event=None):
        if self.tipwindow:
            self.tipwindow.destroy()
            self.tipwindow = None

attributes_list = ["Agi", "Âme", "For", "Int", "Vig"]
attr_dice_values = ["d4", "d6", "d8"]
dice_values = ["d4-2", "d4", "d6", "d8", "d10", "d12"]
dice_to_value = {"d4-2": 2, "d4": 4, "d6": 6, "d8": 8, "d10": 10, "d12": 12}

@lru_cache(maxsize=1)
def charger_catalogue():
    try:
        with open("catalogue_equipement.json", 'r', encoding='utf-8') as f:
            catalogue = json.load(f)
        equipements = []
        for categorie, items in catalogue.items():
            for item in items:
                prix_str = item["Prix"].split()[0]
                try:
                    prix = int(prix_str)
                except ValueError:
                    prix = 100
                equipements.append({
                    "nom": item["Nom"],
                    "prix": prix,
                    "categorie": categorie,
                    "degats": item.get("Dégâts", "-"),
                    "effet": item.get("Effet", "-"),
                    "description": item.get("Description", "")
                })
        return equipements
    except Exception:
        return [
            {"nom": "Sabre", "prix": 100, "categorie": "Armes de mêlée"},
            {"nom": "Pistolet à silex", "prix": 300, "categorie": "Armes à feu"},
            {"nom": "Carte marine", "prix": 150, "categorie": "Objets utilitaires"},
            {"nom": "Longue-vue", "prix": 200, "categorie": "Objets utilitaires"},
            {"nom": "Arbalète", "prix": 250, "categorie": "Armes à distance"}
        ]

@lru_cache(maxsize=1)
def charger_talents():
    try:
        with open("talents.json", 'r', encoding='utf-8') as f:
            return json.load(f)
    except Exception:
        return [
            {"Nom": "Chance du pirate", "Effet": "Ajoute +2 à un jet déjà lancé une fois par partie.", "Type": "Général", "Description": "Permet de forcer le destin en situation critique."},
            {"Nom": "Langue des morts", "Effet": "Permet de contacter un esprit ou fantôme pour un indice.", "Type": "Occulte", "Description": "Utilisable une fois par partie pour obtenir une réponse surnaturelle."},
            {"Nom": "Tir rapide", "Effet": "Permet de tirer deux fois par tour une fois par partie.", "Type": "Combat", "Description": "Offre un bonus tactique en situation de tir soutenu."}
        ]

@lru_cache(maxsize=1)
def charger_classes():
    try:
        with open("classes.json", 'r', encoding='utf-8') as f:
            data = json.load(f)
            return data.get("classes", [])
    except Exception as e:
        print(f"Erreur lors du chargement des classes: {e}")
        return [
            {
                "Nom": "Corsaire",
                "Description": "Navigateurs expérimentés et combattants redoutables.",
                "Attributs": {"Agi": "d8", "Âme": "d6", "For": "d6", "Int": "d4", "Vig": "d6"},
                "Compétences": {"Navigation": "d6", "Combat": "d6", "Tir": "d6"},
                "Talents": ["Chance du pirate", "Don de la tchatche"],
                "Equipements": ["Sabre", "Pistolet à silex"]
            },
            {
                "Nom": "Lurquin",
                "Description": "Voleurs et espions, experts en discrétion.",
                "Attributs": {"Agi": "d8", "Âme": "d6", "For": "d4", "Int": "d6", "Vig": "d6"},
                "Compétences": {"Discrétion": "d6", "Crochetage": "d6", "Perception": "d6"},
                "Talents": ["Oeil de lynx", "Main leste"],
                "Equipements": ["Dague", "Outils de crochetage"]
            }
        ]

EQUIPEMENTS_POSSIBLES = charger_catalogue()
EQUIPEMENTS_POSSIBLES.sort(key=lambda x: (x["categorie"], x["prix"]))

TALENTS_POSSIBLES = charger_talents()
TALENTS_POSSIBLES.sort(key=lambda x: x["Type"])

CLASSES_POSSIBLES = charger_classes()

ARGENT_DEPART = 500
MAX_EQUIPEMENTS = 5

attributes_info = {
    "Agi": "Agilité : Dextérité, coordination, vitesse de réaction.",
    "Âme": "Âme : Force intérieure, volonté, empathie.",
    "For": "Force : Puissance physique brute.",
    "Int": "Intellect : Intelligence, mémoire, éducation.",
    "Vig": "Vigueur : Endurance, résistance physique."
}

@lru_cache(maxsize=1)
def charger_competences():
    try:
        with open("competences.json", 'r', encoding='utf-8') as f:
            data = json.load(f)
            return data.get("competences", [])
    except Exception:
        return [
            {"Nom": "Navigation", "Attribut": "Agilité", "Description": "Piloter un navire, éviter les obstacles, manœuvrer en mer."},
            {"Nom": "Combat", "Attribut": "Agilité", "Description": "Attaque de mêlée, influe sur la Parade."},
            {"Nom": "Tir", "Attribut": "Agilité", "Description": "Armes à distance (pistolet, mousquet, etc.)."},
            {"Nom": "Perception", "Attribut": "Intellect", "Description": "Repérer des pièges, ennemis, mensonges."},
            {"Nom": "Soins", "Attribut": "Intellect", "Description": "Soigner, stabiliser, traiter blessures et maladies."}
        ]

COMPETENCES = charger_competences()

skills_data = {}
skills_info = {}

attr_conversion = {
    "Agilité": "Agi",
    "Force": "For",
    "Intellect": "Int",
    "Âme": "Âme",
    "Vigueur": "Vig"
}

for comp in COMPETENCES:
    nom = comp["Nom"]
    attribut_complet = comp["Attribut"]
    attribut_abrege = attr_conversion.get(attribut_complet, "Int")
    skills_data[nom] = attribut_abrege
    skills_info[nom] = comp["Description"]
ARGENT_DEPART = 500
MAX_EQUIPEMENTS = 5

# Conversion des classes du JSON en dictionnaire pour la compatibilité avec le code existant
classes = {}
for classe in CLASSES_POSSIBLES:
    classes[classe["Nom"]] = {
        "Talents": classe.get("Talents", []),
        "Description": classe.get("Description", ""),
        "Attributs": classe.get("Attributs", {}),
        "Compétences": classe.get("Compétences", {}),
        "Equipements": classe.get("Equipements", [])
    }

# Pour appliquer les tooltips, il suffit d'utiliser CreateToolTip(widget, texte) au bon endroit dans l'interface.
def apply_tooltips(attr_widgets, skill_widgets):
    for attr, widget in attr_widgets.items():
        if attr in attributes_info:
            CreateToolTip(widget, attributes_info[attr])

    for skill, widget in skill_widgets.items():
        if skill in skills_info:
            CreateToolTip(widget, skills_info[skill])


def launch_interface():
    skill_vars = {}
    attr_widgets = {}
    skill_widgets = {}

    def update_options(event=None):
        selected_class = class_var.get()
        if not selected_class:
            return
            
        # Déverrouiller tous les champs maintenant qu'une classe est sélectionnée
        unlock_all_fields()
        
        # Récupérer les données de la classe sélectionnée
        class_data = classes.get(selected_class, {})
        
        # Mettre à jour les talents disponibles
        class_talents = class_data.get("Talents", [])
        talent_menu['values'] = class_talents
        
        # Sélectionner le premier talent par défaut
        if isinstance(class_talents, list) and class_talents:
            talent_var.set(class_talents[0])
            
        # Mettre à jour la disponibilité des talents selon les prérequis
        update_talent_availability()
        
        # Mettre à jour les attributs selon la classe
        class_attrs = class_data.get("Attributs", {})
        for attr, value in class_attrs.items():
            if attr in attr_vars and value in attr_dice_values:
                attr_vars[attr].set(value)
        
        # Mettre à jour les compétences selon la classe
        class_skills = class_data.get("Compétences", {})
        for skill, value in class_skills.items():
            # Trouver la compétence correspondante (en ignorant la casse et les accents)
            for skill_name, (var, attr) in skill_vars.items():
                if skill_name.lower().replace("é", "e").replace("à", "a") == skill.lower().replace("é", "e").replace("à", "a"):
                    if value in dice_values:
                        var.set(value)
                    break
        
        # Réinitialiser puis sélectionner les équipements de la classe
        try:
            # D'abord tout décocher
            for item in equip_vars:
                if isinstance(item, tuple) and len(item) > 0:
                    var = item[0]
                    if hasattr(var, 'set'):
                        var.set(0)
            
            # Ensuite cocher les équipements de la classe
            class_equipments = class_data.get("Equipements", [])
            for equip_name in class_equipments:
                for var, eq in equip_vars:
                    if eq["nom"].lower() == equip_name.lower():
                        var.set(1)
                        break
            
            update_equipement_total()
        except Exception as e:
            print(f"Erreur lors de la mise à jour des équipements: {e}")
        
        # Mettre à jour les compteurs
        update_attr_counter()
        update_skill_counter()

    def validate_and_generate():
        name = name_entry.get()
        selected_class = class_var.get()
        attrs = {attr: dice_to_value[attr_vars[attr].get()] for attr in attributes_list}

        # Vérification des attributs
        total_spent = sum(attr_dice_values.index(attr_vars[a].get()) for a in attributes_list)
        if total_spent != 5:
            messagebox.showerror("Erreur", f"Répartition invalide des attributs : {total_spent}/5 points.")
            return

        # Vérification des champs obligatoires
        if not name or not selected_class:
            messagebox.showerror("Erreur", "Veuillez remplir tous les champs obligatoires (nom et classe).")
            return
            
        # Vérification du talent
        if not talent_var.get() or talent_var.get() == "__aucun_talent_selectionne__":
            messagebox.showerror("Erreur", "Veuillez sélectionner un talent.")
            return
            
        # Vérifier que le talent sélectionné est disponible (prérequis remplis)
        selected_talent = talent_var.get()
        talent_data = next((t for t in TALENTS_POSSIBLES if t["Nom"] == selected_talent), None)
        if talent_data:
            available, reason = check_talent_prerequisite(talent_data)
            if not available:
                messagebox.showerror("Erreur", f"Le talent {selected_talent} n'est pas disponible: {reason}")
                return
            
        # Vérification des équipements
        equipements_choisis = [eq for var, eq in equip_vars if var.get()]
        total_equipement = sum(eq['prix'] for eq in equipements_choisis)
        nb_equipements = len(equipements_choisis)
        talent = talent_var.get()
        
        if nb_equipements < 1:
            messagebox.showerror("Erreur", "Vous devez sélectionner au moins un équipement.")
            return
        if nb_equipements > MAX_EQUIPEMENTS:
            messagebox.showerror("Erreur", f"Vous avez sélectionné trop d'équipements ({nb_equipements} / {MAX_EQUIPEMENTS})")
            return
        if total_equipement > ARGENT_DEPART:
            messagebox.showerror("Erreur", f"Vous avez dépassé le budget équipement ({total_equipement} / {ARGENT_DEPART} po)")
            return

        # Vérification des compétences
        skills_final = {}
        skill_points = 0

        for skill, (var, attr) in skill_vars.items():
            level = var.get()
            if level == "d4-2":
                continue
                
            attr_val = attr_vars[attr].get()
            if attr_val not in attr_dice_values:
                attr_val = "d4"
                
            max_index = dice_values.index(attr_val) + 2
            allowed_values = dice_values[:max_index+1]
            
            if level not in allowed_values:
                messagebox.showerror("Erreur", f"{skill} ne peut pas dépasser {allowed_values[-1]} car {attr} = {attr_val}")
                return
                
            cost = calculate_skill_cost(level)
            skill_points += cost
            skills_final[skill] = level

        if skill_points > 15:
            messagebox.showerror("Erreur", f"Trop de points dépensés en compétences : {skill_points}/15")
            return

        # Calcul des caractéristiques dérivées
        combat_val = dice_to_value[attr_vars["Agi"].get()]
        parade = int(combat_val / 2) + 2
        resistance = int(attrs["Vig"] / 2)
        charisme = int(attrs["Âme"] / 2) - 2

        # Génération du document
        doc = Document("fiche.docx")

        # Préparation des valeurs à injecter
        balises = {
            "nom": name,
            "classe": selected_class,
            "agi": attr_vars["Agi"].get(),
            "ame": attr_vars["Âme"].get(),
            "for": attr_vars["For"].get(),
            "int": attr_vars["Int"].get(),
            "vig": attr_vars["Vig"].get(),
            "parade": str(parade),
            "resistance": str(resistance),
            "charisme": str(charisme),
            "allure": "6",
            "course": f"6 + {attr_vars['Agi'].get().upper()}",
            "equipements": ", ".join([eq['nom'] for eq in equipements_choisis]) if equipements_choisis else "Aucun",
            "talent": talent,
        }
        
        # Ajout des équipements individuels
        for i in range(1, MAX_EQUIPEMENTS + 1):
            if i <= len(equipements_choisis):
                balises[f"equipement{i}"] = equipements_choisis[i-1]['nom']
            else:
                balises[f"equipement{i}"] = ""
            balises[f"equipement{i}_degats"] = ""
            balises[f"equipement{i}_effet"] = ""
            balises[f"equipement{i}_details"] = ""
            balises[f"equipement{i}_complet"] = ""

        # Compétences principales (remplissage explicite, toujours toutes les balises)
        competence_balises = [
            "navigation","escalade","combat","tir","perception","discretion","soins","intimidation","persuasion","reseauxrumeurs","survie","natation","provocation","lancer","pistage","equitation","reparation","crochetage","jeuxparis","recherche","connaissance","courage"
        ]
        for skill in competence_balises:
            # On cherche la compétence correspondante dans skills_data (en ignorant la casse et les caractères spéciaux)
            match = None
            for k in skills_data.keys():
                k_clean = k.lower().replace("é", "e").replace("à", "a").replace("ç", "c").replace("û", "u").replace("&", "&").replace(" ","")
                if k_clean == skill:
                    match = k
                    break
            if match:
                balises[skill] = skills_final.get(match, "d4-2")
            else:
                balises[skill] = "d4-2"
        # Ajoute l'argent restant et les détails des équipements sur la fiche
        balises["argent"] = ARGENT_DEPART - total_equipement
        
        # Ajouter les détails des équipements (dégâts, effets)
        for i, eq in enumerate(equipements_choisis[:MAX_EQUIPEMENTS]):
            idx = i + 1
            # Format amélioré pour les dégâts et effets
            degats = eq['degats'] if 'degats' in eq and eq['degats'] != "-" else ""
            effet = eq['effet'] if 'effet' in eq and eq['effet'] != "-" else ""
            
            # Format simplié pour tous les équipements
            # Stocker les dégâts et effets tels quels, sans formatage supplémentaire
            balises[f"equipement{idx}_degats"] = degats
            balises[f"equipement{idx}_effet"] = effet
            
            # Garder le format détaillé pour les autres balises (pour compatibilité)
            if eq['categorie'].startswith("Armes"):
                portee = ""
                if "portée" in effet.lower():
                    try:
                        portee_part = effet.lower().split("portée")[1].split(".")[0].strip()
                        portee = f"Portée: {portee_part}"
                    except:
                        portee = ""
                balises[f"equipement{idx}_details"] = f"Dégâts: {degats}" + (f" | {portee}" if portee else "")
            else:
                balises[f"equipement{idx}_details"] = effet if effet else ""
            
            # Ajouter un format complet pour chaque équipement (nom + détails)
            details_complets = []
            if degats and degats != "-":
                details_complets.append(f"Dégâts: {degats}")
            if effet and effet != "-":
                # Extraire les informations importantes de l'effet
                if "portée" in effet.lower():
                    try:
                        portee_info = effet.lower().split("portée")[1].split(".")[0].strip()
                        details_complets.append(f"Portée: {portee_info}")
                        
                        # Ajouter d'autres infos comme recharge, PA, etc.
                        autres_infos = []
                        if "recharge" in effet.lower():
                            recharge_info = effet.lower().split("recharge")[1].split(".")[0].strip()
                            autres_infos.append(f"Recharge: {recharge_info}")
                        if "pa" in effet.lower():
                            pa_info = "PA " + effet.lower().split("pa")[1].split(".")[0].strip()
                            autres_infos.append(pa_info)
                        
                        if autres_infos:
                            details_complets.append(" | ".join(autres_infos))
                    except:
                        details_complets.append(effet)
                else:
                    details_complets.append(effet)
            
            balises[f"equipement{idx}_complet"] = f"{eq['nom']} - {' | '.join(details_complets)}" if details_complets else eq['nom']
            
            # S'assurer que les balises pour cet équipement sont bien définies
            print(f"Équipement {idx}: {eq['nom']} - Balises définies: equipement{idx}, equipement{idx}_degats, equipement{idx}_effet, equipement{idx}_details, equipement{idx}_complet")
            
            # Afficher les valeurs des balises pour débogage
            print(f"  - equipement{idx} = '{eq['nom']}'")
            print(f"  - equipement{idx}_degats = '{balises[f'equipement{idx}_degats']}'")
            print(f"  - equipement{idx}_effet = '{balises[f'equipement{idx}_effet']}'")
            print(f"  - equipement{idx}_details = '{balises[f'equipement{idx}_details']}'")
            print(f"  - equipement{idx}_complet = '{balises[f'equipement{idx}_complet']}'")
            
            # Afficher un exemple de ce à quoi cela devrait ressembler dans le document
            print(f"  - Format attendu: '{eq['nom']} {balises[f'equipement{idx}_degats']} {balises[f'equipement{idx}_effet']}'")
        # Fonction de remplacement dans tout le doc - méthode optimisée
        def replace_all(doc, balises):
            # Définir les balises qui sont des dés (attributs et compétences)
            dice_balises = set(attributes_list)
            
            # Précompilation des patterns regex pour plus d'efficacité
            dice_pattern = re.compile(r'^d\d+(-\d+)?$')
            
            # Prétraitement des balises pour éviter de répéter les conversions
            processed_balises = {}
            for balise, valeur in balises.items():
                val_str = str(valeur)
                if balise in dice_balises or dice_pattern.match(val_str.lower()):
                    val_str = val_str.upper()
                processed_balises[balise] = val_str
            
            # Fonction optimisée pour remplacer les balises dans un texte
            def replace_balises(text):
                # Vérification rapide si le texte contient des balises
                if '{{' not in text:
                    return text
                    
                # Utilisation d'une seule expression régulière pour trouver toutes les balises
                # et les remplacer en une seule passe
                def replace_match(match):
                    balise = match.group(1)
                    if balise in processed_balises:
                        return processed_balises[balise]
                    return match.group(0)  # Retourner la balise originale si non trouvée
                
                # Remplacer toutes les balises en une seule passe
                new_text = re.sub(r'\{\{(\w+)\}\}', replace_match, text)
                if new_text != text:
                    print(f"Texte modifié: '{text}' -> '{new_text}'")
                return new_text
            
            # Fonction pour mettre à jour un paragraphe
            def update_paragraph(paragraph, new_text):
                # Supprimer tous les runs existants
                for _ in range(len(paragraph.runs)):
                    paragraph.runs[0]._element.getparent().remove(paragraph.runs[0]._element)
                # Ajouter le nouveau texte
                paragraph.add_run(new_text)
            
            # Traiter tous les paragraphes du document principal
            for paragraph in doc.paragraphs:
                text = paragraph.text
                new_text = replace_balises(text)
                if new_text != text:
                    update_paragraph(paragraph, new_text)
            
            # Traiter les tables
            for table in doc.tables:
                for row in table.rows:
                    for cell in row.cells:
                        for paragraph in cell.paragraphs:
                            text = paragraph.text
                            new_text = replace_balises(text)
                            if new_text != text:
                                update_paragraph(paragraph, new_text)

        replace_all(doc, balises)

        save_dir = filedialog.askdirectory(title="Choisir le dossier de destination")
        if not save_dir:
            messagebox.showwarning("Annulé", "Aucun dossier sélectionné. La génération est annulée.")
            return

        file_path = str(Path(save_dir) / f"Fiche_{name.replace(' ', '_')}.docx")
        doc.save(file_path)
        messagebox.showinfo("Succès", f"Fiche générée : {file_path}")

    root = tk.Tk()
    root.title("Création de Personnage Pirate")
    root.geometry("1080x1080")
    root.minsize(600, 600)
    root.configure(bg="#f5ecd7")
    
    # Canvas principal avec scrollbars
    main_canvas = tk.Canvas(root, bg="#f5ecd7", width=1080, height=1080, highlightthickness=0)
    main_canvas.pack(side="left", fill="both", expand=True)
    
    v_scroll = ttk.Scrollbar(root, orient="vertical", command=main_canvas.yview)
    v_scroll.pack(side="right", fill="y")
    
    h_scroll = ttk.Scrollbar(root, orient="horizontal", command=main_canvas.xview)
    h_scroll.pack(side="bottom", fill="x")
    
    main_canvas.configure(yscrollcommand=v_scroll.set, xscrollcommand=h_scroll.set)
    
    # Frame qui contient tout le contenu
    content_frame = tk.Frame(main_canvas, bg="#f5ecd7")
    window_id = main_canvas.create_window((0, 0), window=content_frame, anchor="nw")

    def on_frame_configure(event):
        main_canvas.configure(scrollregion=main_canvas.bbox("all"))
    content_frame.bind("<Configure>", on_frame_configure)

    # Scroll à la molette
    def _on_mousewheel(event):
        if hasattr(event, 'delta'):
            main_canvas.yview_scroll(int(-1*(event.delta/120)), "units")
        elif hasattr(event, 'num'):
            if event.num == 5:
                main_canvas.yview_scroll(1, "units")
            elif event.num == 4:
                main_canvas.yview_scroll(-1, "units")
    main_canvas.bind_all("<MouseWheel>", _on_mousewheel)
    main_canvas.bind_all("<Button-4>", _on_mousewheel)
    main_canvas.bind_all("<Button-5>", _on_mousewheel)

    # Ajout d'un logo pirate si présent
    skull_img = None
    skull_path = os.path.join(os.path.dirname(__file__), "pirate_skull.png")
    title_row = 0
    if os.path.exists(skull_path):
        skull_img = PhotoImage(file=skull_path)
        logo = tk.Label(content_frame, image=skull_img, bg="#f5ecd7")
        logo.image = skull_img
        logo.grid(row=0, column=0, columnspan=2, pady=(10, 0))
        title_row = 1

    title_font = font.Font(family="Georgia", size=18, weight="bold")
    tk.Label(
        content_frame,
        text="Création de Personnage Pirate",
        font=title_font,
        bg="#f5ecd7",
        fg="#6b3e26"
    ).grid(row=title_row, column=0, columnspan=2, pady=(5, 15))

    style = ttk.Style()
    style.theme_use('clam')
    style.configure('TLabel', background="#f5ecd7", font=("Georgia", 11))
    style.configure('TButton', font=("Georgia", 12, "bold"), foreground="#222", background="#ffe066")
    style.map('TButton', background=[('active', '#ffd700')])
    style.configure('TCombobox', fieldbackground="#fffbe6", background="#fffbe6", font=("Georgia", 11))

    ttk.Separator(content_frame, orient="horizontal").grid(row=title_row+1, column=0, columnspan=2, sticky="ew", pady=(0, 10))
    row_offset = title_row + 2

    tk.Label(content_frame, text="Nom du personnage", bg="#f5ecd7", font=("Georgia", 11, "bold"), fg="#6b3e26").grid(row=row_offset, column=0, sticky="w", padx=8, pady=2)
    name_entry = tk.Entry(content_frame, font=("Georgia", 11))
    name_entry.grid(row=row_offset, column=1, padx=8, pady=2)

    tk.Label(content_frame, text="Classe", bg="#f5ecd7", font=("Georgia", 11, "bold"), fg="#6b3e26").grid(row=row_offset+1, column=0, sticky="w", padx=8, pady=2)
    class_var = tk.StringVar()
    class_menu = ttk.Combobox(content_frame, textvariable=class_var, values=list(classes.keys()), state="readonly", font=("Georgia", 11))
    class_menu.grid(row=row_offset+1, column=1, padx=8, pady=2)
    class_menu.bind("<<ComboboxSelected>>", update_options)

    attr_vars = {}
    attr_comboboxes = []
    # --- Ajout Caractéristiques secondaires à droite des attributs ---
    sec_labels = {}
    sec_vars = {
        "Parade": tk.StringVar(value="Parade : 4"),
        "Résistance": tk.StringVar(value="Résistance : 2"),
        "Charisme": tk.StringVar(value="Charisme : 0"),
        "Allure": tk.StringVar(value="Allure : 6"),
        "Course": tk.StringVar(value="Course : 10"),
    }

    # Définition de sep_row avant son utilisation
    sep_row = row_offset+3+len(attributes_list)
    ttk.Separator(content_frame, orient="horizontal").grid(row=sep_row, column=0, columnspan=2, sticky="ew", pady=(10, 5))
    
    # Créer un cadre pour contenir côte à côte les compétences et l'équipement
    content_split_frame = tk.Frame(content_frame, bg="#f5ecd7")
    content_split_frame.grid(row=sep_row+1, column=0, columnspan=3, sticky="nsew", padx=8, pady=2)
    
    # --- Section COMPÉTENCES (à gauche) ---
    skills_container = tk.Frame(content_split_frame, bg="#f5ecd7")
    skills_container.grid(row=0, column=0, sticky="nw", padx=(0, 10))
    
    tk.Label(skills_container, text="Compétences (15 points max)", 
             bg="#f5ecd7", font=("Georgia", 11, "bold"), fg="#6b3e26").grid(row=0, column=0, sticky="w", pady=(0, 5))

    # --- ÉQUIPEMENT MULTIPLE (à droite) ---
    equip_container = tk.Frame(content_split_frame, bg="#f5ecd7")
    equip_container.grid(row=0, column=1, sticky="nw", padx=(10, 0))
    
    tk.Label(equip_container, text=f"Équipement (budget : {ARGENT_DEPART} pièces, max {MAX_EQUIPEMENTS} objets)", 
             bg="#f5ecd7", font=("Georgia", 11, "bold"), fg="#6b3e26").grid(row=0, column=0, sticky="w", pady=(0, 5))
    
    # Frame simple pour l'équipement, sans scrollbar interne (la scrollbar principale suffira)
    equip_frame = tk.Frame(equip_container, bg="#f5ecd7")
    equip_frame.grid(row=1, column=0, sticky="nw")
    
    # Variables pour les checkboxes
    equip_vars = []
    equip_checkboxes = []
    
    # Grouper par catégorie
    categories = {}
    for eq in EQUIPEMENTS_POSSIBLES:
        if eq["categorie"] not in categories:
            categories[eq["categorie"]] = []
        categories[eq["categorie"]].append(eq)
    
    # Créer les checkboxes par catégorie
    row_index = 0
    for categorie, items in categories.items():
        # Titre de la catégorie
        cat_label = tk.Label(equip_frame, text=categorie, bg="#f5ecd7", font=("Georgia", 10, "bold"), fg="#8B4513")
        cat_label.grid(row=row_index, column=0, sticky="w", pady=(10, 5))
        row_index += 1
        
        # Items de la catégorie
        for eq in items:
            var = tk.IntVar()
            cb = tk.Checkbutton(equip_frame, text=f"{eq['nom']} ({eq['prix']} po)", 
                               variable=var, bg="#f5ecd7", font=("Georgia", 10), 
                               anchor="w", command=lambda: update_equipement_total())
            cb.grid(row=row_index, column=0, sticky="w")
            
            # Tooltip pour afficher les détails
            tooltip_text = f"Catégorie: {eq['categorie']}\nPrix: {eq['prix']} po\nDégâts: {eq['degats']}\nEffet: {eq['effet']}\n\n{eq['description']}"
            CreateToolTip(cb, tooltip_text)
            
            equip_vars.append((var, eq))
            equip_checkboxes.append(cb)
            row_index += 1
    
    # Affichage du total
    equip_total_var = tk.StringVar(value=f"Total: 0 po / {ARGENT_DEPART} po - 0/{MAX_EQUIPEMENTS} objets")
    equip_total_label = tk.Label(equip_container, textvariable=equip_total_var, bg="#f5ecd7", font=("Georgia", 10, "bold"), fg="#6b3e26")
    equip_total_label.grid(row=2, column=0, sticky="w", pady=(8,0))
    
    def update_equipement_total():
        equipements_selectionnes = [(eq, var.get()) for var, eq in equip_vars if var.get()]
        total = sum(eq['prix'] for eq, _ in equipements_selectionnes)
        nb_objets = len(equipements_selectionnes)
        
        equip_total_var.set(f"Total: {total} po / {ARGENT_DEPART} po - {nb_objets}/{MAX_EQUIPEMENTS} objets")
        equip_total_label.config(fg="#b22222" if total > ARGENT_DEPART or nb_objets > MAX_EQUIPEMENTS else "#6b3e26")
            
        if nb_objets >= MAX_EQUIPEMENTS:
            for var, eq in equip_vars:
                if not var.get():
                    for cb in equip_checkboxes:
                        if cb.cget("text").startswith(eq['nom']):
                            cb.config(state="disabled")
        else:
            for cb in equip_checkboxes:
                cb.config(state="normal")
    for i, attr in enumerate(attributes_list):
        tk.Label(content_frame, text=attr, bg="#f5ecd7", font=("Georgia", 11), fg="#6b3e26").grid(row=row_offset+2+i, column=0, sticky="w", padx=8, pady=2)
        var = tk.StringVar(value="d4")
        attr_menu = ttk.Combobox(content_frame, textvariable=var, values=attr_dice_values, state="readonly", width=5, font=("Georgia", 11))
        attr_menu.grid(row=row_offset+2+i, column=1, padx=8, pady=2)
        attr_vars[attr] = var
        attr_widgets[attr] = attr_menu
        attr_comboboxes.append((var, attr_menu))
        # Placement des caractéristiques secondaires à droite
        # On place les 4 caractéristiques secondaires dans l'ordre
        if i < len(sec_vars):
            sec_type = list(sec_vars.keys())[i]
            sec_labels[sec_type] = tk.Label(content_frame, textvariable=sec_vars[sec_type], bg="#f5ecd7", font=("Georgia", 11, "bold"), fg="#b8860b")
            sec_labels[sec_type].grid(row=row_offset+2+i, column=2, sticky="w", padx=(24,8), pady=2)
    attr_counter_var = tk.StringVar()
    attr_counter_label = tk.Label(content_frame, textvariable=attr_counter_var, bg="#f5ecd7", font=("Georgia", 10, "bold"), fg="#6b3e26")
    attr_counter_label.grid(row=row_offset+2+len(attributes_list), column=0, columnspan=2, sticky="w", padx=8, pady=(0, 4))

    def update_secondary():
        attrs = {attr: dice_to_value[attr_vars[attr].get()] for attr in attributes_list}
        parade = int(attrs["Agi"] / 2) + 2
        resistance = int(attrs["Vig"] / 2)
        charisme = int(attrs["Âme"] / 2) - 2
        agi_de = attr_vars["Agi"].get()
        
        sec_vars["Parade"].set(f"Parade : {parade}")
        sec_vars["Résistance"].set(f"Résistance : {resistance}")
        sec_vars["Charisme"].set(f"Charisme : {charisme}")
        sec_vars["Allure"].set(f"Allure : 6")
        sec_vars["Course"].set(f"Course : 6 + {agi_de.upper()}")

    # Lier la mise à jour des carac secondaires à chaque changement d'attribut
    for var, menu in attr_comboboxes:
        var.trace_add('write', lambda *args: update_secondary())
        var.trace_add('write', lambda *args: update_talent_availability())
    update_secondary()

    # sep_row est déjà défini plus haut
    # L'interface d'équipement est maintenant gérée par le catalogue JSON plus haut

    ttk.Separator(content_frame, orient="horizontal").grid(row=sep_row+3, column=0, columnspan=3, sticky="ew", pady=(10, 5))

    # Nous avons déplacé cette section dans la disposition à deux colonnes ci-dessus
    skill_frame = tk.Frame(skills_container, bg="#f5ecd7")
    skill_frame.grid(row=1, column=0, sticky="nw")

    skill_comboboxes = []
    for row_index, (skill, linked_attr) in enumerate(skills_data.items()):
        tk.Label(skill_frame, text=f"{skill} ({linked_attr})", bg="#f5ecd7", font=("Georgia", 10), fg="#6b3e26").grid(row=row_index, column=0, sticky="w", padx=4, pady=1)
        var = tk.StringVar(value="d4-2")
        # On calcule dynamiquement la liste des valeurs max selon l'attribut lié
        def get_skill_values(attr_name):
            attr_val = attr_vars[attr_name].get()
            # Trouver l'index de l'attribut dans attr_dice_values
            if attr_val not in attr_dice_values:
                attr_val = "d4"
            max_index = dice_values.index(attr_val) + 2  # max = attribut + 2 crans
            return dice_values[:max_index+1]  # +1 car slicing exclut la borne
        # On crée le menu avec la bonne liste
        menu = ttk.Combobox(skill_frame, textvariable=var, values=get_skill_values(linked_attr), state="readonly", width=5, font=("Georgia", 10))
        var.set("d4-2")  # Valeur par défaut
        menu.grid(row=row_index, column=1, padx=4, pady=1)
        skill_vars[skill] = (var, linked_attr)
        skill_widgets[skill] = menu
        skill_comboboxes.append((var, menu))
        # Mettre à jour dynamiquement quand l'attribut change
        def update_skill_menu(var=var, menu=menu, linked_attr=linked_attr):
            menu['values'] = get_skill_values(linked_attr)
            if var.get() not in menu['values']:
                var.set('d4-2')
        attr_vars[linked_attr].trace_add('write', lambda *args, var=var, menu=menu, linked_attr=linked_attr: update_skill_menu(var, menu, linked_attr))
        # Mettre à jour les talents disponibles quand une compétence change
        var.trace_add('write', lambda *args: update_talent_availability())

    skill_counter_var = tk.StringVar()
    skill_counter_label = tk.Label(skills_container, textvariable=skill_counter_var, bg="#f5ecd7", font=("Georgia", 10, "bold"), fg="#6b3e26")
    skill_counter_label.grid(row=2, column=0, sticky="w", pady=(4, 0))
    
    # Fonction pour réinitialiser les compétences
    def reset_competences():
        for var, menu in skill_comboboxes:
            var.set("d4-2")
        update_skill_counter()
        update_talent_availability()  # Mettre à jour les talents après réinitialisation
    
    # Bouton Réinitialiser Compétences
    reset_btn = tk.Button(
        skills_container,
        text="Réinitialiser Compétences",
        command=reset_competences,
        bg="#ffd6d6",
        fg="#6b3e26",
        activebackground="#ffaaaa",
        font=("Georgia", 10, "bold"),
        relief="raised",
        bd=2
    )
    reset_btn.grid(row=3, column=0, pady=(8, 8), sticky="ew")
    
    # Talents (déplacé sous le bouton de réinitialisation)
    tk.Label(skills_container, text="Talents (un seul choix possible)", bg="#f5ecd7", font=("Georgia", 11, "bold"), fg="#6b3e26").grid(row=4, column=0, sticky="w", pady=(10, 2))
    
    # Frame pour les talents
    talents_frame = tk.Frame(skills_container, bg="#f5ecd7")
    talents_frame.grid(row=5, column=0, sticky="ew", pady=(0, 10))
    
    # Variable pour stocker le talent sélectionné - initialisée avec une valeur spéciale qui ne correspond à aucun talent
    talent_var = tk.StringVar(value="__aucun_talent_selectionne__")
    
    # Dictionnaire pour stocker les radiobuttons des talents
    talent_radiobuttons = {}
    
    # Fonction pour vérifier si un talent est disponible selon les prérequis
    def check_talent_prerequisite(talent):
        # Si pas de prérequis, le talent est disponible
        if "Prérequis" not in talent:
            return True, ""
            
        prerequis = talent.get("Prérequis", "")
        selected_class = class_var.get()
        
        # Cas 1: Prérequis multiples (objet JSON avec Classe et Attribut)
        if isinstance(prerequis, dict):
            # Initialiser les messages d'erreur
            errors = []
            all_conditions_met = True
            
            # Vérifier les prérequis de classe
            if "Classe" in prerequis:
                classe_requise = prerequis["Classe"]
                # Si classe_requise est null/None, le talent est disponible pour toutes les classes
                if classe_requise is not None and selected_class != classe_requise:
                    all_conditions_met = False
                    errors.append(f"Réservé à la classe {classe_requise}")
            
            # Vérifier les prérequis d'attribut
            if "Attribut" in prerequis:
                attr_condition = prerequis["Attribut"]
                if attr_condition is not None and "+" in attr_condition:
                    # Extraire l'attribut et le niveau requis
                    parts = attr_condition.split(" ")
                    if len(parts) >= 2:
                        attr_name = parts[0]
                        required_level = parts[1].replace("+", "")
                        
                        # Vérifier l'attribut
                        if attr_name in attr_vars:
                            current_level = attr_vars[attr_name].get()
                            required_index = dice_values.index(required_level)
                            current_index = dice_values.index(current_level)
                            
                            if current_index < required_index:
                                all_conditions_met = False
                                errors.append(f"Requiert {attr_name} {required_level}+")
                        else:
                            # Vérifier les compétences
                            attr_found = False
                            for skill_name, (var, _) in skill_vars.items():
                                skill_normalized = skill_name.lower().replace("é", "e").replace("à", "a").replace("ç", "c")
                                attr_normalized = attr_name.lower().replace("é", "e").replace("à", "a").replace("ç", "c")
                                
                                if skill_normalized == attr_normalized or skill_normalized.startswith(attr_normalized):
                                    attr_found = True
                                    current_level = var.get()
                                    if current_level == "d4-2":
                                        all_conditions_met = False
                                        errors.append(f"Requiert {attr_name} {required_level}+")
                                    else:
                                        required_index = dice_values.index(required_level)
                                        current_index = dice_values.index(current_level)
                                        
                                        if current_index < required_index:
                                            all_conditions_met = False
                                            errors.append(f"Requiert {attr_name} {required_level}+")
                            
                            if not attr_found:
                                all_conditions_met = False
                                errors.append(f"Attribut ou compétence {attr_name} introuvable")
            
            # Vérifier les prérequis de compétence
            if "Compétence" in prerequis:
                skill_condition = prerequis["Compétence"]
                if skill_condition is not None and "+" in skill_condition:
                    # Extraire la compétence et le niveau requis
                    parts = skill_condition.split(" ")
                    if len(parts) >= 2:
                        skill_name = parts[0]
                        required_level = parts[1].replace("+", "")
                        
                        # Vérifier si la compétence existe
                        skill_found = False
                        for skill_key, (var, _) in skill_vars.items():
                            skill_key_normalized = skill_key.lower().replace("é", "e").replace("à", "a").replace("ç", "c")
                            skill_name_normalized = skill_name.lower().replace("é", "e").replace("à", "a").replace("ç", "c")
                            
                            if skill_key_normalized == skill_name_normalized or skill_key_normalized.startswith(skill_name_normalized):
                                skill_found = True
                                current_level = var.get()
                                if current_level == "d4-2":
                                    all_conditions_met = False
                                    errors.append(f"Requiert {skill_name} {required_level}+")
                                else:
                                    required_index = dice_values.index(required_level)
                                    current_index = dice_values.index(current_level)
                                    
                                    if current_index < required_index:
                                        all_conditions_met = False
                                        errors.append(f"Requiert {skill_name} {required_level}+")
                        
                        if not skill_found:
                            all_conditions_met = False
                            errors.append(f"Compétence {skill_name} introuvable")
        
            # Résultat final pour prérequis multiples
            if all_conditions_met:
                return True, ""
            else:
                return False, ", ".join(errors)  # Combiner tous les messages d'erreur
        
        # Cas 2: Prérequis simple (string)
        # Vérifier dans la liste des classes
        if prerequis in classes.keys():
            if selected_class == prerequis:
                return True, ""
            else:
                return False, f"Réservé à l'archétype {prerequis}"
                
        # Vérifier les autres classes spéciales comme Chirurgien de bord, Charpentier-Canonnier, etc.
        if prerequis in ["Chirurgien de Bord", "Charpentier-Canonnier", "Capitaine", "Maître Canonnier"]:
            if selected_class == prerequis:
                return True, ""
            else:
                return False, f"Réservé à la classe {prerequis}"
        
        # Si le prérequis est un niveau de compétence (ex: "Âme d6+")
        if "+" in prerequis:
            # Extraire l'attribut/compétence et le niveau requis
            parts = prerequis.split(" ")
            if len(parts) >= 2:
                attr_or_skill = parts[0]
                required_level = parts[1].replace("+", "")
                
                # Vérifier si c'est un attribut
                if attr_or_skill in attr_vars:
                    current_level = attr_vars[attr_or_skill].get()
                    required_index = dice_values.index(required_level)
                    current_index = dice_values.index(current_level)
                    
                    if current_index >= required_index:
                        return True, ""
                    else:
                        return False, f"Requiert {attr_or_skill} {required_level}+"
                
                # Vérifier si c'est une compétence
                for skill_name, (var, _) in skill_vars.items():
                    # Normaliser pour comparer (ignorer casse et accents)
                    skill_normalized = skill_name.lower().replace("é", "e").replace("à", "a").replace("ç", "c")
                    attr_normalized = attr_or_skill.lower().replace("é", "e").replace("à", "a").replace("ç", "c")
                    
                    if skill_normalized == attr_normalized or skill_normalized.startswith(attr_normalized):
                        current_level = var.get()
                        if current_level == "d4-2":  # Non entraîné
                            return False, f"Requiert {attr_or_skill} {required_level}+"
                            
                        required_index = dice_values.index(required_level)
                        current_index = dice_values.index(current_level)
                        
                        if current_index >= required_index:
                            return True, ""
                        else:
                            return False, f"Requiert {attr_or_skill} {required_level}+"
                
                return False, f"Requiert {prerequis}"
        
        # Si le prérequis est une compétence ou attribut avec un niveau spécifique
        elif " " in prerequis:
            parts = prerequis.split(" ")
            if len(parts) >= 2:
                attr_or_skill = parts[0]
                required_level = parts[1]
                
                # Logique similaire à ci-dessus
                # ...
                
        return False, f"Prérequis non rempli: {prerequis}"
    
    # Fonction pour mettre à jour l'état des talents selon les prérequis
    def update_talent_availability(*args):
        for talent_name, rb in talent_radiobuttons.items():
            # Trouver le talent correspondant
            talent_data = next((t for t in TALENTS_POSSIBLES if t["Nom"] == talent_name), None)
            if talent_data:
                available, reason = check_talent_prerequisite(talent_data)
                
                if available:
                    rb.config(state="normal", fg="#000000")
                    # Mettre à jour le tooltip pour inclure les prérequis
                    prereq_text = f"Prérequis: {talent_data.get('Prérequis', 'Aucun')}\n" if "Prérequis" in talent_data else ""
                    tooltip_text = f"Type: {talent_data['Type']}\n{prereq_text}Effet: {talent_data['Effet']}\n\n{talent_data['Description']}"
                    
                    # Trouver et mettre à jour le tooltip existant
                    for child in rb.winfo_children():
                        if isinstance(child, tk.Toplevel):
                            child.destroy()
                    CreateToolTip(rb, tooltip_text)
                else:
                    rb.config(state="disabled", fg="#999999")
                    # Mettre à jour le tooltip pour inclure la raison
                    prereq_text = f"Prérequis: {talent_data.get('Prérequis', 'Aucun')} - {reason}\n"
                    tooltip_text = f"Type: {talent_data['Type']}\n{prereq_text}Effet: {talent_data['Effet']}\n\n{talent_data['Description']}"
                    
                    # Trouver et mettre à jour le tooltip existant
                    for child in rb.winfo_children():
                        if isinstance(child, tk.Toplevel):
                            child.destroy()
                    CreateToolTip(rb, tooltip_text)
                    
                    # Si ce talent est actuellement sélectionné, le désélectionner
                    if talent_var.get() == talent_name:
                        talent_var.set("__aucun_talent_selectionne__")
    
    # Grouper par type
    types_talents = {}
    for talent in TALENTS_POSSIBLES:
        if talent["Type"] not in types_talents:
            types_talents[talent["Type"]] = []
        types_talents[talent["Type"]].append(talent)
    
    # Créer les radiobuttons par type
    row_index = 0
    for type_talent, talents in types_talents.items():
        # Titre du type
        type_label = tk.Label(talents_frame, text=type_talent, bg="#f5ecd7", font=("Georgia", 10, "bold"), fg="#8B4513")
        type_label.grid(row=row_index, column=0, sticky="w", pady=(10, 5))
        row_index += 1
        
        # Talents de ce type
        for talent in talents:
            rb = tk.Radiobutton(talents_frame, text=talent["Nom"], 
                              variable=talent_var, value=talent["Nom"], 
                              bg="#f5ecd7", font=("Georgia", 10), 
                              anchor="w")
            rb.grid(row=row_index, column=0, sticky="w")
            
            # Stocker le radiobutton pour pouvoir le mettre à jour plus tard
            talent_radiobuttons[talent["Nom"]] = rb
            
            # Préparer le texte du tooltip avec les prérequis
            prereq_text = f"Prérequis: {talent.get('Prérequis', 'Aucun')}\n" if "Prérequis" in talent else ""
            tooltip_text = f"Type: {talent['Type']}\n{prereq_text}Effet: {talent['Effet']}\n\n{talent['Description']}"
            CreateToolTip(rb, tooltip_text)
            
            row_index += 1
    
    # Garder le menu combobox pour la compatibilité avec le code existant
    talent_menu = ttk.Combobox(skills_container, textvariable=talent_var, state="readonly", font=("Georgia", 11))
    talent_menu.grid_remove()  # On le cache car on utilise les radiobuttons à la place
    
    # Ajouter un bouton pour désélectionner tous les talents
    def clear_talent_selection():
        talent_var.set("__aucun_talent_selectionne__")
        
    # Déplacer le bouton 'Aucun talent' sous la zone des talents
    clear_talent_btn = ttk.Button(skills_container, text="Aucun talent", command=clear_talent_selection)
    clear_talent_btn.grid(row=6, column=0, sticky="ew", pady=(0, 4))

    # --- Boutons Sauvegarder / Charger ---
    def sauvegarder_personnage():
        nom_pj = nom_var.get().strip()
        if not nom_pj:
            messagebox.showerror("Erreur", "Veuillez renseigner le nom du personnage avant de sauvegarder.")
            return
        data = {
            "nom": nom_pj,
            "classe": class_var.get(),
            "attributs": {attr: attr_vars[attr].get() for attr in attr_vars},
            "competences": {skill: skill_vars[skill][0].get() for skill in skill_vars},
            "talent": talent_var.get()
        }
        nom_fichier = f"sauvegarde_{nom_pj}.json"
        try:
            with open(nom_fichier, "w", encoding="utf-8") as f:
                json.dump(data, f, ensure_ascii=False, indent=2)
            messagebox.showinfo("Sauvegarde réussie", f"Personnage sauvegardé dans {nom_fichier}")
        except Exception as e:
            messagebox.showerror("Erreur", f"Erreur lors de la sauvegarde : {e}")

    def charger_personnage():
        nom_pj = nom_var.get().strip()
        if not nom_pj:
            messagebox.showerror("Erreur", "Veuillez renseigner le nom du personnage à charger.")
            return
        nom_fichier = f"sauvegarde_{nom_pj}.json"
        try:
            with open(nom_fichier, "r", encoding="utf-8") as f:
                data = json.load(f)
            # Restaurer les valeurs
            for attr, val in data.get("attributs", {}).items():
                if attr in attr_vars:
                    attr_vars[attr].set(val)
            for skill, val in data.get("competences", {}).items():
                if skill in skill_vars:
                    skill_vars[skill][0].set(val)
            if data.get("classe") in class_var['values']:
                class_var.set(data["classe"])
            if data.get("talent") in talent_radiobuttons:
                talent_var.set(data["talent"])
            else:
                talent_var.set("__aucun_talent_selectionne__")
            update_skill_counter()
            update_talent_availability()
            messagebox.showinfo("Chargement réussi", f"Personnage chargé depuis {nom_fichier}")
        except FileNotFoundError:
            messagebox.showerror("Erreur", f"Le fichier {nom_fichier} est introuvable.")
        except Exception as e:
            messagebox.showerror("Erreur", f"Erreur lors du chargement : {e}")


    # Fonction pour sauvegarder l'état du personnage dans un fichier JSON
    def sauvegarder_personnage():
        # Vérifier si le nom est vide
        nom_pj = name_entry.get().strip()
        if not nom_pj:
            messagebox.showerror("Erreur", "Veuillez entrer un nom de personnage avant de sauvegarder.")
            return
            
        # Créer un dictionnaire avec toutes les données du personnage
        data = {
            "nom": nom_pj,
            "classe": class_var.get(),
            "attributs": {attr: var.get() for attr, var in attr_vars.items()},
            "competences": {skill: var.get() for skill, (var, _) in skill_vars.items()},
            "talent": talent_var.get(),
            "equipement": [eq["nom"] for var, eq in equip_vars if var.get()]
        }
        
        # Nom du fichier de sauvegarde
        filename = f"sauvegarde_{nom_pj.replace(' ', '_')}.json"
        
        try:
            with open(filename, 'w', encoding='utf-8') as f:
                json.dump(data, f, ensure_ascii=False, indent=4)
            messagebox.showinfo("Sauvegarde", f"Personnage sauvegardé dans {filename}")
        except Exception as e:
            messagebox.showerror("Erreur", f"Erreur lors de la sauvegarde : {str(e)}")
    
    # Fonction pour charger un personnage depuis un fichier JSON
    def charger_personnage():
        try:
            # Trouver les fichiers de sauvegarde disponibles
            sauvegardes = list(pathlib.Path('.').glob('sauvegarde_*.json'))
            if not sauvegardes:
                messagebox.showinfo("Information", "Aucune sauvegarde trouvée.")
                return
                
            # Extraire les noms des personnages des noms de fichiers
            noms_pj = [f.stem.replace('sauvegarde_', '').replace('_', ' ') for f in sauvegardes]
            
            # Créer une fenêtre de sélection
            select_window = tk.Toplevel()
            select_window.title("Charger un personnage")
            select_window.geometry("400x300")
            select_window.configure(bg="#f5ecd7")
            select_window.transient(content_frame)
            select_window.grab_set()
            
            tk.Label(select_window, text="Sélectionnez un personnage à charger :", 
                   bg="#f5ecd7", font=("Georgia", 12, "bold"), fg="#6b3e26").pack(pady=10)
            
            # Créer une liste déroulante
            listbox = tk.Listbox(select_window, font=("Georgia", 11), bg="#fffbe6")
            listbox.pack(fill=tk.BOTH, expand=True, padx=20, pady=10)
            
            for nom in noms_pj:
                listbox.insert(tk.END, nom)
            
            def load_selected():
                if listbox.curselection():
                    index = listbox.curselection()[0]
                    filename = f"sauvegarde_{noms_pj[index].replace(' ', '_')}.json"
                    
                    try:
                        with open(filename, 'r', encoding='utf-8') as f:
                            data = json.load(f)
                            
                        # Mettre à jour l'interface avec les données chargées
                        name_entry.delete(0, tk.END)
                        name_entry.insert(0, data["nom"])
                        
                        # Classe
                        class_var.set(data["classe"])
                        update_options(None)  # Mettre à jour les options en fonction de la classe
                        
                        # Attributs
                        for attr, value in data["attributs"].items():
                            if attr in attr_vars:
                                attr_vars[attr].set(value)
                        
                        # Compétences
                        for skill, value in data["competences"].items():
                            if skill in skill_vars:
                                skill_vars[skill][0].set(value)
                        
                        # Talent
                        talent_var.set(data["talent"])
                        
                        # Équipement - réinitialiser d'abord
                        for var, _ in equip_vars:
                            var.set(0)
                        
                        # Ajouter les équipements sauvegardés
                        for item_name in data["equipement"]:
                            for i, (var, item) in enumerate(equip_vars):
                                if item["nom"] == item_name:
                                    var.set(1)
                                    break
                        
                        # Mettre à jour le total d'équipement
                        update_equipement_total()
                        
                        # Mettre à jour les compteurs et la disponibilité des talents
                        update_attr_counter()
                        update_skill_counter()
                        update_talent_availability()
                        
                        messagebox.showinfo("Chargement", f"Personnage {data['nom']} chargé avec succès.")
                        select_window.destroy()
                    except Exception as e:
                        messagebox.showerror("Erreur", f"Erreur lors du chargement : {str(e)}")
                else:
                    messagebox.showwarning("Avertissement", "Veuillez sélectionner un personnage.")
            
            # Boutons
            buttons_frame = tk.Frame(select_window, bg="#f5ecd7")
            buttons_frame.pack(pady=10, fill=tk.X)
            
            tk.Button(buttons_frame, text="Charger", command=load_selected,
                    bg="#ffe066", fg="#6b3e26", font=("Georgia", 11, "bold")).pack(side=tk.LEFT, padx=20, expand=True, fill=tk.X)
            tk.Button(buttons_frame, text="Annuler", command=select_window.destroy,
                    bg="#ffd6d6", fg="#6b3e26", font=("Georgia", 11, "bold")).pack(side=tk.RIGHT, padx=20, expand=True, fill=tk.X)
                    
        except Exception as e:
            messagebox.showerror("Erreur", f"Erreur générale : {str(e)}")
    
    # Cadre pour les boutons de sauvegarde/chargement et génération
    buttons_frame = tk.Frame(content_frame, bg="#f5ecd7")
    buttons_frame.grid(row=sep_row+3, column=0, columnspan=3, sticky="ew", pady=(10, 0))
    
    # Boutons de sauvegarde et chargement
    save_load_frame = tk.Frame(buttons_frame, bg="#f5ecd7")
    save_load_frame.pack(fill=tk.X, pady=5)
    
    tk.Button(
        save_load_frame,
        text="Sauvegarder Personnage",
        command=sauvegarder_personnage,
        bg="#d0f0c0",  # Vert clair
        fg="#2e5c1a",  # Vert foncé
        activebackground="#b0e090",
        font=("Georgia", 11, "bold"),
        relief="raised",
        bd=2
    ).pack(side=tk.LEFT, fill=tk.X, expand=True, padx=5)
    
    tk.Button(
        save_load_frame,
        text="Charger Personnage",
        command=charger_personnage,
        bg="#add8e6",  # Bleu clair
        fg="#104e8b",  # Bleu foncé
        activebackground="#87cefa",
        font=("Georgia", 11, "bold"),
        relief="raised",
        bd=2
    ).pack(side=tk.RIGHT, fill=tk.X, expand=True, padx=5)
    
    ttk.Separator(content_frame, orient="horizontal").grid(row=sep_row+4, column=0, columnspan=3, sticky="ew", pady=(10, 5))

    # Bouton de génération de fiche
    tk.Button(
        content_frame,
        text="Générer la Fiche",
        command=validate_and_generate,
        bg="#ffe066",
        fg="#6b3e26",
        activebackground="#ffd700",
        font=("Georgia", 13, "bold"),
        relief="raised",
        bd=3
    ).grid(row=sep_row+5, column=0, columnspan=3, pady=14, sticky="ew")

    # Fonction optimisée pour calculer le coût d'un niveau de compétence
    def calculate_skill_cost(level):
        if level == "d4-2":
            return 0
        if level == "d4":
            return 1
        return dice_values.index(level)
    
    def update_attr_counter(*args):
        total = sum(attr_dice_values.index(attr_vars[a].get()) for a in attributes_list)
        rest = 5 - total
        color = "#b22222" if total > 5 else "#6b3e26"
        attr_counter_label.config(fg=color)
        attr_counter_var.set(f"Attributs : {total}/5 points dépensés ({rest} restants)")

    def update_skill_counter(*args):
        skill_points = sum(
            calculate_skill_cost(var.get()) 
            for skill, (var, attr) in skill_vars.items() 
            if var.get() != "d4-2"
        )
        rest = 15 - skill_points
        color = "#b22222" if skill_points > 15 else "#6b3e26"
        skill_counter_label.config(fg=color)
        skill_counter_var.set(f"Compétences : {skill_points}/15 points dépensés ({rest} restants)")
    
    # Fonctions pour verrouiller/déverrouiller les champs
    def lock_all_fields():
        # Verrouiller les attributs
        for attr, menu in attr_widgets.items():
            menu.config(state="disabled")
        
        # Verrouiller les compétences
        for skill, menu in skill_widgets.items():
            menu.config(state="disabled")
        
        # Verrouiller les talents
        for widget in talents_frame.winfo_children():
            if isinstance(widget, tk.Radiobutton):
                widget.config(state="disabled")
        clear_talent_btn.config(state="disabled")
        
        # Verrouiller les équipements
        for cb in equip_checkboxes:
            cb.config(state="disabled")
    
    def unlock_all_fields():
        # Déverrouiller les attributs
        for attr, menu in attr_widgets.items():
            menu.config(state="readonly")
        
        # Déverrouiller les compétences
        for skill, menu in skill_widgets.items():
            menu.config(state="readonly")
        
        # Déverrouiller les talents
        for widget in talents_frame.winfo_children():
            if isinstance(widget, tk.Radiobutton):
                widget.config(state="normal")
        clear_talent_btn.config(state="normal")
        
        # Déverrouiller les équipements
        for cb in equip_checkboxes:
            cb.config(state="normal")

    for var, menu in attr_comboboxes:
        var.trace_add('write', lambda *args: (update_attr_counter(), update_skill_counter()))
    for var, menu in skill_comboboxes:
        var.trace_add('write', lambda *args: update_skill_counter())

    update_attr_counter()
    update_skill_counter()

    apply_tooltips(attr_widgets, skill_widgets)
    
    # Verrouiller tous les champs au démarrage sauf le nom et la classe
    lock_all_fields()
    
    # Ajouter une description de classe
    class_description_var = tk.StringVar()
    class_description_label = tk.Label(content_frame, textvariable=class_description_var, bg="#f5ecd7", font=("Georgia", 10, "italic"), fg="#6b3e26", wraplength=400, justify="left")
    class_description_label.grid(row=row_offset+1, column=2, sticky="w", padx=(24,8), pady=2)
    
    # Mettre à jour la description quand la classe change
    def update_class_description(*args):
        selected_class = class_var.get()
        if selected_class in classes:
            description = classes[selected_class].get("Description", "")
            class_description_var.set(description)
        else:
            class_description_var.set("")
    
    class_var.trace_add('write', lambda *args: update_class_description())
    
    root.mainloop()

launch_interface()
